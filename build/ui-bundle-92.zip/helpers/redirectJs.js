'use strict'

function myFunction (message) {
  return 'Hello, ' + message + '!'
}

module.exports = myFunction
